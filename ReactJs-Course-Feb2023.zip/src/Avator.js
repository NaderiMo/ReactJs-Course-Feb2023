function Avator() {
    return (
        <div>

        <img  src="./images/img_avator.jpg" height="150" weight="150" />

        </div>
    )
}
export default Avator;