import "./myCss/myCss.css";

function Login(){
    return(
        <div>
        <form method="post">
            <br />
            <br />
            <br />
            <div class="imgcontainer">
                <img src="./images/img_avatar.jpg" height="150" width="150"/>
            </div>
            <div class="container">
                <lable ><b>Username  </b></lable>
                <input type="text" placeholder="Enter your Username" ></input>
                <br />
                <br />
                <label ><b>Password  </b></label>
                <input type="password" placeholder="Enter your Password" ></input>
                <br />
                <br />
                <button type="submit">Login</button>
            </div>
        </form>
    </div>
    )
}

export default Login;